import base64
import json
import re
import csv
from matplotlib.ticker import NullLocator
import streamlit as st
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.chat_models import AzureChatOpenAI
from langchain.vectorstores import Chroma
import io
import openai
import pandas as pd
#from load_css import local_css
import plotly.express as px
from datetime import datetime
from dash import Dash, dcc, html, Input, Output
import plotly.graph_objects as go
import json, urllib
from PIL import Image, ImageFilter, ImageDraw
import plotly.express as px
import shutil
import sankeyflow as sf
import os
from langchain.chat_models import ChatOpenAI
## langchain test from here
import pandas as pd
import numpy as np
    

#export LANGCHAIN_TRACING_V2=true
#export LANGCHAIN_ENDPOINT=https://api.smith.langchain.com
#export LANGCHAIN_API_KEY="ls__2a39f1201f6e474c87c8eda61ac2b927"
#export LANGCHAIN_PROJECT="DTV"

# Update with your API URL if using a hosted instance of Langsmith.
#os.environ["LANGCHAIN_ENDPOINT"] = https://api.smith.langchain.com
#os.environ["LANGCHAIN_API_KEY"] = "ls__2a39f1201f6e474c87c8eda61ac2b927"  # Update with your API key
#project_name = "ABC"  # Update with your project name

os.environ['LANGCHAIN_TRACING_V2'] = 'true'
os.environ['LANGCHAIN_ENDPOINT'] = 'https://api.smith.langchain.com'
os.environ['LANGCHAIN_API_KEY'] = 'ls__b53eed5869be48b6894b8d78c727d82c'
os.environ['LANGCHAIN_PROJECT'] = 'Test_Architecture_Design'

## langchain test till here

# Utility class to store session state
class SessionState:
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

# Function to get the current session state
def get_session_state(**kwargs):
    if 'session_state' not in st.session_state:
        st.session_state['session_state'] = SessionState(**kwargs)
    return st.session_state['session_state']

# loading unstructured files of all sorts as LangChain Documents
def load_document(file):
    # from langchain.document_loaders import UnstructuredFileLoader

    from langchain.document_loaders import TextLoader
    loader = TextLoader(file)
    data = loader.load()
    print(data)
    return data

def anstodf(aa):
    # Extract lines
    #aa = """ aa """
    lines = aa.splitlines()

    # Create empty lists 
    feature = []
    value = []

    # Loop through lines to extract features and values
    for line in lines:
        # Split line on colon
        parts = line.split(":")
  
    # First part is feature
        feature.append(parts[0].strip()) 
  
    # Second part is value
        value.append(parts[1].strip())

    # Create dataframe  
    df = pd.DataFrame({
        "Feature": feature,
        "Value": value
    })

    # Print dataframe
    st.write(df)

# splitting data in chunks
def chunk_data(data, chunk_size=256, chunk_overlap=200):
    from langchain.text_splitter import RecursiveCharacterTextSplitter
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    chunks = text_splitter.split_documents(data)
    return chunks

# create embeddings using OpenAIEmbeddings() and save them in a Chroma vector store
def create_embeddings(chunks):
    ###### 
    print('This is chunks: ',chunks)
    embeddings = OpenAIEmbeddings()
    ######
    print('This is embddings: ',embeddings)
    from langchain.embeddings.azure_openai import AzureOpenAIEmbeddings

    # embeddings = AzureOpenAIEmbeddings()
    vector_store = Chroma.from_documents(chunks, embeddings)
    return vector_store

def ask_and_get_answer(vector_store, q, k=10):
    from langchain.chains import RetrievalQA
    from langchain.chat_models import ChatOpenAI

    #llm = ChatOpenAI(model='davinci', temperature=1, max_tokens= None)
    #llm = ChatOpenAI(model="claude")
    #llm = ChatOpenAI(model='gpt-3.5-turbo', temperature=0.4, max_tokens= 2048)
    
    #####
    llm = ChatOpenAI(model='gpt-4', temperature=0.34, max_tokens= 4096)
    ######
    # llm = AzureChatOpenAI(model='gpt-4', temperature=0.34, max_tokens= 4096)   ### Azure code ####

    #llm = ChatOpenAI(model='gpt-4-1106-preview', temperature=0.34, max_tokens= 4096)
    #llm = ChatOpenAI(model='gpt-4-1106-preview', temperature=0.34, max_tokens= 4096)

    retriever = vector_store.as_retriever(search_type='similarity', search_kwargs={'k': k})
    chain = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=retriever)

    answer = chain.run(q)
    return answer

# calculate embedding cost using tiktoken
def calculate_embedding_cost(texts):
    import tiktoken
    enc = tiktoken.encoding_for_model('text-embedding-ada-002')
    total_tokens = sum([len(enc.encode(page.page_content)) for page in texts])
    return total_tokens, total_tokens / 1000 * 0.0004

def check_openai_api_key_exist():
    if 'OPENAI_API_KEY' not in os.environ:
        st.error('Please provide your OpenAI API key in the sidebar.')
        st.stop()

def is_api_key_valid(api_key):
    import openai
    openai.api_key = api_key
    try:
        response = openai.Completion.create(
            engine="davinci-002",
            prompt="This is a test.",
            max_tokens=5
        )
        print(response)
    except Exception as e:
        return False, str(e)
    else:
        return True, ""
    
   

def clear_text_input():
    st.session_state.text_input = ''

def start_over_with_new_document():
    st.session_state.text_input = ''
    # delete the vector store from the session state
    del st.session_state.vs
    # display message to user
    #st.info('Please upload new documents to continue after clearing or updating the current ones.')

def click_button():
        st.session_state.button = not st.session_state.button
            # add data button widget
    
    
def initialize_session_state():
    if 'button' not in st.session_state:
        st.session_state.button = False

initialize_session_state()   

    

        

    #st.button("Submit")
with st.sidebar:
        st.markdown(f"""
        <style>
        div.stButton > button:first-child {{
            background-color: #6fa8dc; #cfe2f3; ##0074D9;
            color: white;
        }} 
        </style>""", unsafe_allow_html=True)
        # text_input for the OpenAI API key
        api_key = st.text_input('OpenAI API Key:', type='password')
        if api_key:
            os.environ['OPENAI_API_KEY'] = api_key

        # check if the API key is not valid
        if api_key and not is_api_key_valid(api_key):
            st.error('Invalid OpenAI API key. Please provide a valid key.')
            st.stop()

        #llm = ChatOpenAI()
        #st.write(llm.invoke("Hello, world!"))

        # file uploader widget
        #uploaded_files = st.file_uploader('Upload any file format with text to analyze:', accept_multiple_files=True)
        
       
        # chunk size number widget
        global chunk_size
        chunk_size = st.number_input('Chunk size:', min_value=100, max_value=8192, value=1024)

        # k number input widget
        global k
        k = st.number_input(' Instances:', min_value=1, max_value=20, value=10)

        # add data button widget
        add_data = None

        st.button('Clear Session & Vectors', on_click=click_button)
        
        if is_api_key_valid(api_key):
            add_data = st.button('Add Data')
            print("api key valid") #validation
                ### code for file upload on Business Process
        else:
            st.info('No OpenAI API key. Please provide a valid key.')
        
        
        #setting the Debug flag from here
        #if st.button("Turn On Debug Mode"):
        #    st.write("Debug Mode Flag On!") 
            
        #else:
        #    st.write("Debug Mode Flag Off!") 
            
        
        state = st.checkbox("Debug Mode On/Off")

        if state:
            st.write("Debug Mode ON")
            global_debug_flag = True
        else:
            st.write("Debug Mode OFF")
            global_debug_flag = False
        
        #setting the Debug flag till here
            
if __name__ == "__main__":
    import os
    
    # two images in sidebar next to each other
    col1, col2 = st.sidebar.columns(2)
    #col1.image('images/OpenAI_logo.png')
    #col2.image('images/langchain-chroma-light.png')

    #st.header('LLM Question-Answering Application')
    #st.image('directv_hz_rgb_pos.png')
    
    
    # code to adjust DTV logo from here
    # Load image
    st.image('DOX_BIG.png', caption=None, width=150, use_column_width=150, clamp=True, channels="RGB", output_format="auto")
    #st.markdown('<hr style="height:1.5px;border:none;color:#333;background-color:#00539B;" />', unsafe_allow_html=True)
    # code to adjust DTV logo till here
    #st.caption("Product Sales Diagnostic tool")
    #st.write("Product Sales Diagnostic tool")
    #st.header ("Product Sales Diagnostic tool")
    st.markdown('<h1 style="color:#00a6d6;font-size:20px;">Amdocs brAIn - Test Architecture - Powered by Generative AI</h1>', unsafe_allow_html=True)
    #st.markdown('<h1 style="color:#00629b;font-size:20px;">Product Sales Diagnostic tool</h1>', unsafe_allow_html=True)
    #st.markdown("""<div>style="position: fixed; bottom: 0; right: 0;" width="100">""", unsafe_allow_html=True)
    #st.markdown("""<div>Developed By Amdocs</div><img src="Amdocs.jpg" style="position: fixed; bottom: 0; right: 0;" width="100">""", unsafe_allow_html=True)
    #st.image('DTV Amdocs.PNG', caption=None, width=400, use_column_width=200, clamp=True, channels="RGB", output_format="auto")
    st.divider()
    
    
    #####
    # code for file upload from here
    # Define a variable to store the uploaded file content
    
    new_feat_uploaded_files_content= None
    
    new_feat_uploaded_files = st.file_uploader('', accept_multiple_files=True, key='new_feat')
    st.button(label="Step 1. Upload New Feature Documents Here")

    # Check if a file was uploaded
    if new_feat_uploaded_files is not None and len(new_feat_uploaded_files) > 0:
        # Read the first file content as a string
        new_feat_uploaded_files_content = new_feat_uploaded_files[0].read().decode("utf-8")

        # Display the file content
        if global_debug_flag:
            st.caption("New feat uploaded files content:")
            st.write(new_feat_uploaded_files_content) 

      
    Business_Process_uploaded_files = st.file_uploader('', accept_multiple_files=True, key='businessproc')
    st.button(label="Step 2. Upload Business Process Documents Here")
    
    # Assigning Feature's Prompt file to var from here
    hld_prompt_buffer = io.BytesIO()
    with open('HLD_TCD_Prompt_v01.txt','rb') as file1:
        hld_prompt_buffer.write(file1.read())
    
    hld_prompt_buffer = hld_prompt_buffer.getvalue()
    hld_prompt = hld_prompt_buffer.decode('utf-8')
    
    # Assigning Feature's Prompt file to var till here

    # Assigning Detailed Test Cases Generation Prompt file to var from here:
    Detailed_TCD_prompt_buffer = io.BytesIO()
    with open('Detailed_TCD_Prompt_v06.txt','rb') as file2:
        Detailed_TCD_prompt_buffer.write(file2.read())
    
    Detailed_TCD_prompt_buffer = Detailed_TCD_prompt_buffer.getvalue()
    Detailed_TCD_prompt = Detailed_TCD_prompt_buffer.decode('utf-8')
    #st.write(Detailed_TCGen_prompt)
    # Assigning Detailed Test Cases Generation Prompt file to var till here:

   
        
        
    ### New Feature uploaded Doc Processing: High Level Design from here:
    st.write("") 
    get_detailed_button_stat = st.button('Step 3. Generate High Level and Detailed Test Designs', on_click=click_button)
    #st.write(get_detailed_button_stat) 
    print("Start Step 3")
    if new_feat_uploaded_files and Business_Process_uploaded_files and is_api_key_valid(api_key) and get_detailed_button_stat:
        q = hld_prompt + new_feat_uploaded_files_content
        print ("Test Design loop") #validation
        if global_debug_flag:
            st.caption("hld Prompt combined with new feat uploaded file content")
            st.write(q)
            print("hld prompt") #validation
        i=1
        df_new_feat = pd.DataFrame()
        Detailed_TC_df = pd.DataFrame()
        print("dataframe loaded") #validation
        #columns=['Features', 'Analysis'])
        #st.header("QUALITATIVE INSIGHTS")
        
        

        for uploaded_file in Business_Process_uploaded_files:
            if not os.path.exists('./docs/'):
                    os.mkdir('./docs/')

            # list to store all the chunks
            all_chunks = []
            # writing the file from RAM to the current directory on disk
            bytes_data = uploaded_file.read()
            file_name = os.path.join('./docs/', uploaded_file.name)
            with open(file_name, 'wb') as f:
                f.write(bytes_data)
            print(file_name+"saved in docs folder")
            print("chunk size = "+str(chunk_size))
            data = load_document(file_name)
            print(file_name+" Loaded successfully")
            chunks = chunk_data(data, chunk_size=chunk_size)
            print(f'File name: {os.path.basename(file_name)}, Chunk size: {chunk_size}, Chunks: {len(chunks)}')
            all_chunks.extend(chunks)

            tokens, embedding_cost = calculate_embedding_cost(all_chunks)
            print(f'Embedding cost: ${embedding_cost:.4f}')

            # creating the embeddings and returning the Chroma vector store
            vector_store = create_embeddings(all_chunks)

            # saving the vector store in the streamlit session state (to be persistent between reruns)
            st.session_state.vs = vector_store
            #st.success('Uploaded, chunked and embedded successfully.')
            if(global_debug_flag):
              st.caption("New Feature Prompt + Business Process")
              st.write(q)
              st.caption('vs going in to model for detailed tcs')
              st.write(st.session_state.vs)
            answer = ask_and_get_answer(st.session_state.vs, q, k)
            json_data = answer
            if(global_debug_flag):
              st.caption("Json Data for New Feature's Generated High Level Test Design ")
              st.write(json_data)
            feat_data = json.loads(json_data)
            df_new_feat = pd.DataFrame(feat_data["new_features"])
            

            q1 = Detailed_TCD_prompt  + new_feat_uploaded_files_content  
            q2 = Detailed_TCD_prompt + json_data   
            if(global_debug_flag):
                    st.caption("Prompt for Detailed Test Design")
                    st.write(q1)
                    st.caption('vs going in to model for detailed tcs')
                    st.write(st.session_state.vs)
            Detailed_TCS = ask_and_get_answer(st.session_state.vs, q2, k)
            Detailed_TCS_json_data = Detailed_TCS
            
          
            #st.write(anstodf(answer))
            
            #if(global_debug_flag):
            #    st.subheader("JSON Data")
            #    st.code(json_data, language='json')
            
            #if st.w('Get High Level Design on New Features'):
            #gen_highlevel_button_stat = st.button('Generate High Level Test Design', on_click=click_button)
            #st.write(gen_highlevel_button_stat)   
            #if gen_highlevel_button_stat:  
            try:
                
                if get_detailed_button_stat:   
                    st.subheader("High Level Design on Test Scenarios")
                    st.table(df_new_feat)
                    st.download_button(label="Download High Level Test Design",
                                                    data=df_new_feat.to_csv(index=False),
                                                    file_name='highlevelTestCases.csv',
                                                    mime='text/csv',
                                                    on_click=click_button
                                                    #button_color= '#6fa8dc',
                                                    #color= '#FFFFFF'
                                                    )
                    
                    #else:
                #    st.write("upload Business Process or New Feature Doc to generate HLL Design and Detailed Test Design")
        ### New Feature uploaded Doc Processing: High Level Design till here:

    ### Detailed Test Cases Generation from here:
              
                 
                    
                    
                        
                    if(global_debug_flag):
                        st.caption("Detailed_TCS_json_data")
                        st.write(Detailed_TCS_json_data)
                        
                    Detailed_TCS_data = json.loads(Detailed_TCS_json_data)
                    Detailed_TC_df = pd.DataFrame(Detailed_TCS_data["test_cases"])
                        
                    if(global_debug_flag):
                        st.caption("JSON Data")
                        st.code(Detailed_TCS_json_data, language='json')
                    
                    
                    st.subheader("Detailed Test Design")
                    st.table(Detailed_TC_df)
                        #Create a download button for the CSV file
                        #df_det_test_cases = pd.DataFrame(Detailed_TC_df)
                        #if st.button("Download Detailed Test Cases"):
                    csv1 = Detailed_TC_df.to_csv(index=False)
                    csv2 = df_new_feat.to_csv(index=False)
                    csv_new_det = "High Level Test Design" + csv2 + " Detailed Test Design " + csv1
                    data=csv_new_det

                    
                    
                    st.download_button(label="Download High level and Detailed Test Design",
                                            data=csv_new_det,
                                            file_name='HLL_DetailedTestDesign.csv',
                                            mime='text/csv',
                                            on_click=click_button
                                            #button_color= '#6fa8dc',
                                            #color= '#FFFFFF'
                                            )
            except json.JSONDecodeError as e:
                # Handle the JSON decoding error
                st.write(f"Error decoding JSON: {str(e)}")
                gen_highlevel_button_stat = False
                
                    

    ### Detailed Test Cases Generation till here:
            
    
    ### Deleting the docs folder code from here
            #    os.rmdir('./docs/')
    # deleting files from the docs folder after they have been chunked and embedded
            #for file in os.listdir('./docs/'):
            #   os.remove(os.path.join('./docs/', file))
        if (os.listdir('./docs')):
            for filename in os.listdir('./docs'):
                file_path = os.path.join('./docs', filename)
                try:
                    if os.path.isfile(file_path) or os.path.islink(file_path):
                        os.unlink(file_path)
                    elif os.path.isdir(file_path):
                        shutil.rmtree(file_path)
                except Exception as e:
                        st.write('Failed to delete %s. Reason: %s' % (file_path, e))

            os.rmdir('./docs')
           #st.text_area("INSIGHT "+ str(i) + " :", value=answer, height=300, key=i)
            
            
            # Create and Display the dataframe with json file
            
            #
            #incrementing the i counter for number of files
            i+=1
        ### Deleting the docs folder code till here
        # Create a button
    button_clicked = st.button("Upload to ALM")
    if button_clicked:
        st.write("ALM Implementation in Process")
    # Check if the button is clicked
    
    st.divider() #st.info('Please upload one or more files to continue.')
