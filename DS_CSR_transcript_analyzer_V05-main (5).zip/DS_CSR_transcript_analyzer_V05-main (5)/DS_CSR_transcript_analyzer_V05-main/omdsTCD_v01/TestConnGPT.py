import os
from openai import AzureOpenAI
   
#proxy setup for Amdocs Network
os.environ['http_proxy'] = 'http://genproxy.amdocs.com:8080'
os.environ['https_proxy'] = 'http://genproxy.amdocs.com:8080'

client = AzureOpenAI(
    api_key="c7c47fffdd5a4ff68deddc337a7cdd19",  
    api_version="2023-09-15-preview",
    azure_endpoint = "https://aqe-atdm.openai.azure.com/"
    )
    
deployment_name='AQE-ATDM' #This will correspond to the custom name you chose for your deployment when you deployed a model. Use a gpt-35-turbo-instruct deployment. 
    
# Send a completion call to generate an answer
print('Sending a test completion job')
start_phrase = 'Write a tagline for an ice cream shop. '
response = client.completions.create(model=deployment_name, prompt=start_phrase, max_tokens=10)
print(start_phrase+response.choices[0].text)