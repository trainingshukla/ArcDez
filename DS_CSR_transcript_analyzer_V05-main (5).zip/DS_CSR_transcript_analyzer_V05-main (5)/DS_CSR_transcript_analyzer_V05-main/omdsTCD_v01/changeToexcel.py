import pandas as pd
from io import StringIO

# Your data
data = """
End to End Flow Name | Step_number | Test Case Name | Description | Expected results
--- | --- | --- | --- | ---
Account Creation | 1 | Validate Access to TELCOM Website | Navigate to TELCOM's official website | Successful navigation and display of TELCOM's homepage
Account Creation | 2 | Validate "Sign Up" or "Create Account" | Click on "Sign Up" or "Create Account" button | New account creation page opens
Account Creation | 3 | Validate Personal Information Fields | Enter valid personal information details | Successful submission of personal information
Account Creation | 4 | Validate Username and Password Creation | Enter valid email address as username and secure password | Successful creation of username and password
Account Creation | 5
"""

# Remove the line with '---'
data = '\n'.join([line for line in data.split('\n') if not line.startswith('---')])

# Create a pandas DataFrame from the data
df = pd.read_csv(StringIO(data), sep='|')

# Write the DataFrame to an Excel file
df.to_excel('output.xlsx', index=False)