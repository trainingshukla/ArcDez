import os
from openai import AzureOpenAI
from langchain_openai import AzureOpenAIEmbeddings

# os.environ["AZURE_OPENAI_API_KEY"] = "c7c47fffdd5a4ff68deddc337a7cdd19"
# os.environ["AZURE_OPENAI_ENDPOINT"] = "https://aqe-atdm.openai.azure.com/"
# os.environ["model"] = "text-embedding-ada-002"

# os.environ['http_proxy'] = 'http://genproxy.amdocs.com:8080'
# os.environ['https_proxy'] = 'http://genproxy.amdocs.com:8080'
# llm = AzureOpenAI(
#     azure_deployment="AQE-ATDM",
#     api_version='2023-09-15-preview'
# )
# llm("This is Amdocs")
# # query_result = embeddings.embed_query(text)
# # doc_result = embeddings.embed_documents([text])
# # doc_result[0][:5]

# print("the llm",llm)



import os
from langchain.chat_models import AzureChatOpenAI
from langchain.schema import HumanMessage

openai_api_key = 'c7c47fffdd5a4ff68deddc337a7cdd19'
llm = AzureChatOpenAI(deployment_name="AQE-ATDM",
                      model='gpt-4-32k',
                      openai_api_version="2023-09-15-preview",
                      openai_api_key=openai_api_key, azure_endpoint="https://aqe-atdm.openai.azure.com",
                      max_tokens=4096)
msg = HumanMessage(content='''
                   how much time do you take to respond with a token of 2000''')
print(llm(messages=[msg]))