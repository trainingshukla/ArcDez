import requests
import os
from openai import AzureOpenAI
from langchain_openai import AzureOpenAIEmbeddings
from langchain.schema import HumanMessage

os.environ["AZURE_OPENAI_API_KEY"] = "c7c47fffdd5a4ff68deddc337a7cdd19"
os.environ["AZURE_OPENAI_ENDPOINT"] = "https://aqe-atdm.openai.azure.com"

# Set the default timeout for all requests
# requests.adapters.DEFAULT_RETRIES = 5  #retries to resolve timeout
os.environ['http_proxy'] = 'http://genproxy.amdocs.com:8080'
os.environ['https_proxy'] = 'http://genproxy.amdocs.com:8080'

# client = AzureOpenAI(
#   api_key = "c7c47fffdd5a4ff68deddc337a7cdd19",  
#   api_version = "2023-09-15-preview",
#   azure_endpoint ="https://aqe-atdm.openai.azure.com/"
# )

# response = client.embeddings.create(
#     input = "my text which will be used for embedding",
#     model= "text-embedding-ada-002"
# )

# print(response.model_dump_json(indent=2))

from langchain_openai import AzureOpenAIEmbeddings

embeddings = AzureOpenAIEmbeddings(
    azure_deployment="AQEChatEmbedding",
    openai_api_version="2023-09-15-preview",
)
text = "My name is Arunava, I'm not very kind , I have food always for friends who comes in my home"
query_result = embeddings.embed_query(text)
doc_result = embeddings.embed_documents([text,"my name is arunava"])
# [["embedded data of string1"],["embedded data of string2"]]

print(doc_result[1][5:7])
# print("Query Result")
# print(query_result)
# print("Query document")
# print(doc_result[1])

# [-0.012222584727053133,
#  0.0072103982392216145,
#  -0.014818063280923775,
#  -0.026444746872933557,
#  -0.0034330499700826883]