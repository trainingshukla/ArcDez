import base64
import json
import re
import csv
from matplotlib.ticker import NullLocator
import streamlit as st
import io
import pandas as pd
import shutil
import os 
from langchain.embeddings.azure_openai import AzureOpenAIEmbeddings
from langchain.chat_models import AzureChatOpenAI
from langchain.vectorstores import Chroma
from langchain.chains import RetrievalQA
from langchain.chat_models import ChatOpenAI
from langchain_openai import OpenAIEmbeddings
from langchain.chains import ConversationalRetrievalChain
from langchain.prompts import PromptTemplate

#Configure Azure endpoints , Langchain endpoint and API keys - .env to be created later for security reasons.
# os.environ['LANGCHAIN_TRACING_V2'] = 'true'
# os.environ['LANGCHAIN_ENDPOINT'] = 'https://api.smith.langchain.com'
# os.environ['LANGCHAIN_API_KEY'] = 'ls__b53eed5869be48b6894b8d78c727d82c'
# os.environ['LANGCHAIN_PROJECT'] = 'Test_Architecture_Design'
#proxy configuration 
# os.environ['http_proxy'] = 'http://genproxy.amdocs.com:8080'
# os.environ['https_proxy'] = 'https://genproxy.amdocs.com:8080'

os.environ['http_proxy'] = 'http://genproxy.amdocs.com:8080'
os.environ['https_proxy'] = 'http://genproxy.amdocs.com:8080'

azure_openai_endpoint = 'https://aqe-atdm.openai.azure.com/'
azure_openai_api_key = 'c7c47fffdd5a4ff68deddc337a7cdd19'
azure_ada_endpoint = 'https://aqe-atdm.openai.azure.com/'
azure_ada_api_key = 'c7c47fffdd5a4ff68deddc337a7cdd19'

# Utility class to store session state
class SessionState:
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

# Function to get the current session state
def get_session_state(**kwargs):
    if 'session_state' not in st.session_state:
        st.session_state['session_state'] = SessionState(**kwargs)
    return st.session_state['session_state']

# loading unstructured files of all sorts as LangChain Documents
def load_document(file):
    # from langchain.document_loaders import UnstructuredFileLoader
    from langchain.document_loaders import TextLoader
    loader = TextLoader(file)
    data = loader.load()
    print(data)
    return data

def anstodf(aa):
    # Extract lines
    #aa = """ aa """
    lines = aa.splitlines()
    # Create empty lists 
    feature = []
    value = []
    # Loop through lines to extract features and values
    for line in lines:
        # Split line on colon
        parts = line.split(":")
    # First part is feature
        feature.append(parts[0].strip()) 
    # Second part is value
        value.append(parts[1].strip())
    # Create dataframe  
    df = pd.DataFrame({
        "Feature": feature,
        "Value": value
    })
    # Print dataframe
    st.write(df)




# Function to chunk data
def chunk_data(data, chunk_size=256, chunk_overlap=200):
    from langchain.text_splitter import RecursiveCharacterTextSplitter
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    chunks = text_splitter.split_documents(data)
    return chunks

# Function to create embeddings using AzureOpenAIEmbeddings
# def create_embeddings(chunks):
#     embeddings = AzureOpenAIEmbeddings(model='text-embedding-ada-002',
#                           azure_deployment='AQEChatEmbedding',
#                           azure_endpoint=azure_openai_endpoint,
#                           api_key=azure_openai_api_key,
#                           openai_api_version ='2023-09-15-preview')
#     vector_store = Chroma.from_documents(chunks, embeddings)
#     print (embeddings)  #validation 
#     return vector_store

def create_embeddings(chunks):
    embeddings = AzureOpenAIEmbeddings(
        deployment='AQEChatEmbedding',
        model='text-embedding-ada-002',
        azure_endpoint='https://aqe-atdm.openai.azure.com/',
        openai_api_type='azure',
        openai_api_key='c7c47fffdd5a4ff68deddc337a7cdd19'
)
    vector_store = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings
    )
    print ("embedding functions returns : /n /n",embeddings)  #validation 
    return vector_store

# Function to ask questions and get answers using AzureChatOpenAI
# def ask_and_get_answer(vector_store, q, k=10):
#     llm = AzureChatOpenAI(model='gpt-4-32k',
#                           azure_deployment='AQE-ATDM',
#                           azure_endpoint=azure_openai_endpoint,
#                           api_key=azure_openai_api_key,
#                           openai_api_version ='2023-09-15-preview')
#     retriever = vector_store.as_retriever(search_type='similarity', search_kwargs={'k': k})
#     chain = ChatOpenAI(llm=llm, retriever=retriever)
#     answer = chain.run(q)
#     return answer



#Function to ask questions and get answers using AzureChatOpenAI
def ask_and_get_answer(vector_store, q, k=10):
    llm = AzureChatOpenAI(
        model='gpt-4-32k',
        deployment_name='AQE-ATDM',
        openai_api_type='azure',
        openai_api_key='c7c47fffdd5a4ff68deddc337a7cdd19',
        azure_endpoint='https://aqe-atdm.openai.azure.com/',
        openai_api_version='2023-09-15-preview'
    )
    retriever = vector_store.as_retriever(search_type='similarity', search_kwargs={'k': k})
    # chain = RetrievalQA.from_chain_type(llm=llm,
    #                                         retriever=retriever,
    #                                         chain_type="stuff",
    #                                         return_source_documents=True,
    #                                         verbose=True)
    # # AzureChatOpenAI(llm=llm, retriever=retriever,openai_api_key='c7c47fffdd5a4ff68deddc337a7cdd19',openai_api_version='2023-09-15-preview',azure_endpoint='https://aqe-atdm.openai.azure.com/')
    # # answer = chain.invoke(q)
    # answer = chain.run(q)
    # print ("answer chain checking",chain)
    # # print ("answer answer2 checking",answer)
    # return answer
    chain = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=retriever)

    answer = chain.run(q)
    return answer


    # text = "this is a test document"
    # query_result = embeddings.embed_query(text)
    # doc_result = embeddings.embed_documents([text])
    # doc_result[0][:5]
    # print (doc_result[0][:5])  #validation 
    # return doc_result


# Function to calculate embedding cost using tiktoken
def calculate_embedding_cost(texts):
    import tiktoken
    enc = tiktoken.encoding_for_model('text-embedding-ada-002')
    total_tokens = sum([len(enc.encode(page.page_content)) for page in texts])
    return total_tokens, total_tokens / 1000 * 0.0004

def check_openai_api_key_exist():
    if 'OPENAI_API_KEY' not in os.environ:
        st.error('Please provide your OpenAI API key in the sidebar.')
        st.stop()

# Function to check if the API key is valid
def is_api_key_valid(api_key):
    import openai
    openai.api_key = api_key
    try:
        response = openai.completions.create(
            engine="ada",
            prompt="This is a test.",
            max_tokens=5
        )
        print(response)
    except Exception as e:
        # return False, str(e)
        return True
    else:
        return True, ""


# Function to clear text input
def clear_text_input():
    st.session_state.text_input = ''

# Function to start over with a new document
def start_over_with_new_document():
    st.session_state.text_input = ''
    # delete the vector store from the session state
    del st.session_state.vs


# Function to handle button click event
def click_button():
    st.session_state.button = not st.session_state.button

# Function to initialize session state
def initialize_session_state():
    if 'button' not in st.session_state:
        st.session_state.button = False

initialize_session_state()

# Streamlit sidebar
with st.sidebar:
        st.markdown(f"""
        <style>
        div.stButton > button:first-child {{
            background-color: #6fa8dc; #cfe2f3; ##0074D9;
            color: white;
        }} 
        </style>""", unsafe_allow_html=True)
        # text_input for the OpenAI API key
        api_key = st.text_input('OpenAI API Key:', type='password')
        if api_key:
            os.environ['OPENAI_API_KEY'] = api_key

        # check if the API key is not valid
        if api_key and not is_api_key_valid(api_key):
            st.error('Invalid OpenAI API key. Please provide a valid key.')
            st.stop()
        # chunk size number widget
        global chunk_size
        chunk_size = st.number_input('Chunk size:', min_value=100, max_value=8192, value=2048)

        # k number input widget
        global k
        k = st.number_input(' Instances:', min_value=1, max_value=20, value=10)

        # add data button widget
        add_data = None

        st.button('Clear Session & Vectors', on_click=click_button)
        
        if is_api_key_valid(api_key):
            add_data = st.button('Add Data')
            print("api key valid") #validation
                ### code for file upload on Business Process
        else:
            st.info('No OpenAI API key. Please provide a valid key.')
        state = st.checkbox("Debug Mode On/Off")
        if state:
            st.write("Debug Mode ON")
            global_debug_flag = True
        else:
            st.write("Debug Mode OFF")
            global_debug_flag = False

# Main Streamlit app
if __name__ == "__main__":
    # Your existing code for the main app
    import os
    
    # two images in sidebar next to each other
    col1, col2 = st.sidebar.columns(2)
    # code to adjust DTV logo from here
    # Load image
    st.image('DOX_BIG.png', caption=None, width=150, use_column_width=150, clamp=True, channels="RGB", output_format="auto")
    st.markdown('<h1 style="color:#00a6d6;font-size:20px;">Amdocs brAIn - Test Architecture - Powered by Generative AI</h1>', unsafe_allow_html=True)
    st.divider()
    
    
    #####
    # code for file upload from here
    # Define a variable to store the uploaded file content
    
    new_feat_uploaded_files_content= None
    
    new_feat_uploaded_files = st.file_uploader('', accept_multiple_files=True, key='new_feat')
    st.button(label="Step 1. Upload New Feature Documents Here")

    # Check if a file was uploaded
    if new_feat_uploaded_files is not None and len(new_feat_uploaded_files) > 0:
        # Read the first file content as a string
        new_feat_uploaded_files_content = new_feat_uploaded_files[0].read().decode("utf-8")

        # Display the file content
        if global_debug_flag:
            st.caption("New feat uploaded files content:")
            st.write(new_feat_uploaded_files_content) 

      
    Business_Process_uploaded_files = st.file_uploader('', accept_multiple_files=True, key='businessproc')
    st.button(label="Step 2. Upload Business Process Documents Here")
    
    # Assigning Feature's Prompt file to var from here
    hld_prompt_buffer = io.BytesIO()
    with open('HLD_TCD_Prompt_v01.txt','rb') as file1:
        hld_prompt_buffer.write(file1.read())
    
    hld_prompt_buffer = hld_prompt_buffer.getvalue()
    hld_prompt = hld_prompt_buffer.decode('utf-8')
    
    # Assigning Feature's Prompt file to var till here

    # Assigning Detailed Test Cases Generation Prompt file to var from here:
    Detailed_TCD_prompt_buffer = io.BytesIO()
    with open('Detailed_TCD_Prompt_v06.txt','rb') as file2:
        Detailed_TCD_prompt_buffer.write(file2.read())
    
    Detailed_TCD_prompt_buffer = Detailed_TCD_prompt_buffer.getvalue()
    Detailed_TCD_prompt = Detailed_TCD_prompt_buffer.decode('utf-8')
    # Assigning Detailed Test Cases Generation Prompt file to var till here:
    ### New Feature uploaded Doc Processing: High Level Design from here:
    st.write("") 
    get_detailed_button_stat = st.button('Step 3. Generate High Level and Detailed Test Designs', on_click=click_button)
    print("Start Step 3")
    if new_feat_uploaded_files and Business_Process_uploaded_files and is_api_key_valid(api_key) and get_detailed_button_stat:
        q = hld_prompt + new_feat_uploaded_files_content
        print ("Test Design loop") #validation
        if global_debug_flag:
            st.caption("hld Prompt combined with new feat uploaded file content")
            st.write(q)
            print("hld prompt") #validation
        i=1
        df_new_feat = pd.DataFrame()
        Detailed_TC_df = pd.DataFrame()
        print("dataframe loaded") #validation       
        

        for uploaded_file in Business_Process_uploaded_files:
            if not os.path.exists('./docs/'):
                    os.mkdir('./docs/')

            # list to store all the chunks
            all_chunks = []
            # writing the file from RAM to the current directory on disk
            bytes_data = uploaded_file.read()
            file_name = os.path.join('./docs/', uploaded_file.name)
            with open(file_name, 'wb') as f:
                f.write(bytes_data)
            print(file_name+"saved in docs folder")
            print("chunk size = "+str(chunk_size))
            data = load_document(file_name)
            print(file_name+" Loaded successfully")
            chunks = chunk_data(data, chunk_size=chunk_size)
            print(f'File name: {os.path.basename(file_name)}, Chunk size: {chunk_size}, Chunks: {len(chunks)}')
            all_chunks.extend(chunks)

            tokens, embedding_cost = calculate_embedding_cost(all_chunks)
            print(f'Embedding cost: ${embedding_cost:.4f}')

            # creating the embeddings and returning the Chroma vector store
            vector_store = create_embeddings(all_chunks)

            # saving the vector store in the streamlit session state (to be persistent between reruns)
            st.session_state.vs = vector_store
            #st.success('Uploaded, chunked and embedded successfully.')
            if(global_debug_flag):
              st.caption("New Feature Prompt + Business Process")
              st.write(q)
              st.caption('vs going in to model for detailed tcs')
              st.write(st.session_state.vs)
            answer = ask_and_get_answer(st.session_state.vs, q, k)
            json_data = answer
            if(global_debug_flag):
              st.caption("Json Data for New Feature's Generated High Level Test Design ")
              st.write(json_data)
            feat_data = json.loads(json_data)
            df_new_feat = pd.DataFrame(feat_data["new_features"])
            

            q1 = Detailed_TCD_prompt  + new_feat_uploaded_files_content  
            q2 = Detailed_TCD_prompt + json_data   
            if(global_debug_flag):
                    st.caption("Prompt for Detailed Test Design")
                    st.write(q1)
                    st.caption('vs going in to model for detailed tcs')
                    st.write(st.session_state.vs)
            Detailed_TCS = ask_and_get_answer(st.session_state.vs, q2, k)
            Detailed_TCS_json_data = Detailed_TCS
            try:
                
                if get_detailed_button_stat:   
                    st.subheader("High Level Design on Test Scenarios")
                    st.table(df_new_feat)
                    st.download_button(label="Download High Level Test Design",
                                                    data=df_new_feat.to_csv(index=False),
                                                    file_name='highlevelTestCases.csv',
                                                    mime='text/csv',
                                                    on_click=click_button
                                                    #button_color= '#6fa8dc',
                                                    #color= '#FFFFFF'
                                                    )
    ### Detailed Test Cases Generation from here:
                    if(global_debug_flag):
                        st.caption("Detailed_TCS_json_data")
                        st.write(Detailed_TCS_json_data)
                        
                    Detailed_TCS_data = json.loads(Detailed_TCS_json_data)
                    Detailed_TC_df = pd.DataFrame(Detailed_TCS_data["test_cases"])
                        
                    if(global_debug_flag):
                        st.caption("JSON Data")
                        st.code(Detailed_TCS_json_data, language='json')
                    
                    
                    st.subheader("Detailed Test Design")
                    st.table(Detailed_TC_df)
                        #Create a download button for the CSV file
                        #df_det_test_cases = pd.DataFrame(Detailed_TC_df)
                        #if st.button("Download Detailed Test Cases"):
                    csv1 = Detailed_TC_df.to_csv(index=False)
                    csv2 = df_new_feat.to_csv(index=False)
                    csv_new_det = "High Level Test Design" + csv2 + " Detailed Test Design " + csv1
                    data=csv_new_det

                    
                    
                    st.download_button(label="Download High level and Detailed Test Design",
                                            data=csv_new_det,
                                            file_name='HLL_DetailedTestDesign.csv',
                                            mime='text/csv',
                                            on_click=click_button
                                            #button_color= '#6fa8dc',
                                            #color= '#FFFFFF'
                                            )
            except json.JSONDecodeError as e:
                # Handle the JSON decoding error
                st.write(f"Error decoding JSON: {str(e)}")
                gen_highlevel_button_stat = False
                
                    

    ### Detailed Test Cases Generation till here:
        if (os.listdir('./docs')):
            for filename in os.listdir('./docs'):
                file_path = os.path.join('./docs', filename)
                try:
                    if os.path.isfile(file_path) or os.path.islink(file_path):
                        os.unlink(file_path)
                    elif os.path.isdir(file_path):
                        shutil.rmtree(file_path)
                except Exception as e:
                        st.write('Failed to delete %s. Reason: %s' % (file_path, e))

            os.rmdir('./docs')
            #incrementing the i counter for number of files
            i+=1
        # Create a button
    button_clicked = st.button("Upload to ALM")
    if button_clicked:
        st.write("ALM Implementation in Process")
    # Check if the button is clicked
    
    st.divider() #st.info('Please upload one or more files to continue.')
