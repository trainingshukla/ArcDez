import json
import re
import csv
from matplotlib.ticker import NullLocator
import streamlit as st
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores import Chroma
import io
import openai
import pandas as pd
#from load_css import local_css
import plotly.express as px
from datetime import datetime
from dash import Dash, dcc, html, Input, Output
import plotly.graph_objects as go
import json, urllib
from PIL import Image, ImageFilter, ImageDraw
import plotly.express as px
import shutil
import sankeyflow as sf
import os
from langchain.chat_models import ChatOpenAI
## langchain test from here


#export LANGCHAIN_TRACING_V2=true
#export LANGCHAIN_ENDPOINT="https://api.smith.langchain.com"
#export LANGCHAIN_API_KEY="ls__2a39f1201f6e474c87c8eda61ac2b927"
#export LANGCHAIN_PROJECT="DTV"

# Update with your API URL if using a hosted instance of Langsmith.
#os.environ["LANGCHAIN_ENDPOINT"] = "https://api.smith.langchain.com"
#os.environ["LANGCHAIN_API_KEY"] = "ls__2a39f1201f6e474c87c8eda61ac2b927"  # Update with your API key
#project_name = "DTV"  # Update with your project name
#os.environ['LANGCHAIN_TRACING_V2'] = 'true'
#os.environ['LANGCHAIN_ENDPOINT'] = 'https://api.smith.langchain.com'
#os.environ['LANGCHAIN_API_KEY'] = 'ls__2a39f1201f6e474c87c8eda61ac2b927'
#os.environ['LANGCHAIN_PROJECT'] = 'DTV'

## langchain test till here

# loading unstructured files of all sorts as LangChain Documents
def load_document(file):
    from langchain.document_loaders import UnstructuredFileLoader
    loader = UnstructuredFileLoader(file)
    data = loader.load()
    return data

def anstodf(aa):
    # Extract lines
    #aa = """ aa """
    lines = aa.splitlines()

    # Create empty lists 
    feature = []
    value = []

    # Loop through lines to extract features and values
    for line in lines:
        # Split line on colon
        parts = line.split(":")
  
    # First part is feature
        feature.append(parts[0].strip()) 
  
    # Second part is value
        value.append(parts[1].strip())

    # Create dataframe  
    df = pd.DataFrame({
        "Feature": feature,
        "Value": value
    })

    # Print dataframe
    st.write(df)

# splitting data in chunks
def chunk_data(data, chunk_size=256, chunk_overlap=20):
    from langchain.text_splitter import RecursiveCharacterTextSplitter
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    chunks = text_splitter.split_documents(data)
    return chunks


# create embeddings using OpenAIEmbeddings() and save them in a Chroma vector store
def create_embeddings(chunks):
    embeddings = OpenAIEmbeddings()
    vector_store = Chroma.from_documents(chunks, embeddings)
    return vector_store


def ask_and_get_answer(vector_store, q, k=3):
    from langchain.chains import RetrievalQA
    from langchain.chat_models import ChatOpenAI

    #llm = ChatOpenAI(model='davinci', temperature=1, max_tokens= None)
    #llm = ChatOpenAI(model="claude")
    #llm = ChatOpenAI(model='gpt-3.5-turbo', temperature=1, max_tokens= None)
    llm = ChatOpenAI(model='gpt-4', temperature=0.34, max_tokens= 1024)

    retriever = vector_store.as_retriever(search_type='similarity', search_kwargs={'k': k})
    chain = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=retriever)

    answer = chain.run(q)
    return answer


# calculate embedding cost using tiktoken
def calculate_embedding_cost(texts):
    import tiktoken
    enc = tiktoken.encoding_for_model('text-embedding-ada-002')
    total_tokens = sum([len(enc.encode(page.page_content)) for page in texts])
    return total_tokens, total_tokens / 1000 * 0.0004


def check_openai_api_key_exist():
    if 'OPENAI_API_KEY' not in os.environ:
        st.error('Please provide your OpenAI API key in the sidebar.')
        st.stop()


def is_api_key_valid(api_key):
    import openai
    openai.api_key = api_key
    try:
        response = openai.Completion.create(
            engine="davinci",
            prompt="This is a test.",
            max_tokens=5
        )
    except:
        return False
    else:
        return True


def clear_text_input():
    st.session_state.text_input = ''


def start_over_with_new_document():
    st.session_state.text_input = ''
    # delete the vector store from the session state
    del st.session_state.vs
    # display message to user
    #st.info('Please upload new documents to continue after clearing or updating the current ones.')


if __name__ == "__main__":
    import os
    
    # two images in sidebar next to each other
    col1, col2 = st.sidebar.columns(2)
    #col1.image('images/OpenAI_logo.png')
    #col2.image('images/langchain-chroma-light.png')

    #st.header('LLM Question-Answering Application')
    #st.image('directv_hz_rgb_pos.png')
    
    
    # code to adjust DTV logo from here
    # Load image
    st.image('directv_hz_rgb_pos.png', caption=None, width=150, use_column_width=150, clamp=True, channels="RGB", output_format="auto")
    #st.markdown('<hr style="height:1.5px;border:none;color:#333;background-color:#00539B;" />', unsafe_allow_html=True)
    # code to adjust DTV logo till here
    #st.caption("Product Sales Diagnostic tool")
    #st.write("Product Sales Diagnostic tool")
    st.header ("Product Sales Diagnostic tool")
    st.markdown('<h1 style="color:#00a6d6;font-size:20px;">Product Sales Diagnostic tool</h1>', unsafe_allow_html=True)
    st.markdown('<h1 style="color:#00629b;font-size:20px;">Product Sales Diagnostic tool</h1>', unsafe_allow_html=True)
    #st.markdown("""<div>style="position: fixed; bottom: 0; right: 0;" width="100">""", unsafe_allow_html=True)
    #st.markdown("""<div>Developed By Amdocs</div><img src="Amdocs.jpg" style="position: fixed; bottom: 0; right: 0;" width="100">""", unsafe_allow_html=True)
    #st.image('DTV Amdocs.PNG', caption=None, width=400, use_column_width=200, clamp=True, channels="RGB", output_format="auto")
    st.divider()
    

    #####
    # code for file upload from here
    
    uploaded_files = st.file_uploader('', accept_multiple_files=True)

    # code for file upload till here
    #####
    
    #add_data = st.button('Upload Transcripts')
    
    # Assining Prompt file to var
    text1_buffer = io.BytesIO()
    with open('Prompt_Ver_1_5.txt','rb') as file1:
        text1_buffer.write(file1.read())
    
    import pandas as pd
    import numpy as np
    

    text1_buffer = text1_buffer.getvalue()
    text1 = text1_buffer.decode('utf-8')
    

        # add data button widget
    add_data = None
        # Upload Button impl
    if 'button' not in st.session_state:
        st.session_state.button = False

    def click_button():
        st.session_state.button = not st.session_state.button

    st.button('Analyze Transcripts', on_click=click_button)

    st.markdown(f"""
    <style>
    div.stButton > button:first-child {{
        background-color: #6fa8dc; #cfe2f3; ##0074D9;
        color: white;
    }} 
    </style>""", unsafe_allow_html=True)

    #st.button("Submit")

    with st.sidebar:
        # text_input for the OpenAI API key
        api_key = st.text_input('OpenAI API Key:', type='password')
        if api_key:
            os.environ['OPENAI_API_KEY'] = api_key

        # check if the API key is not valid
        if api_key and not is_api_key_valid(api_key):
            st.error('Invalid OpenAI API key. Please provide a valid key.')
            
            st.stop()

        #llm = ChatOpenAI()
        #st.write(llm.invoke("Hello, world!"))

        # file uploader widget
        #uploaded_files = st.file_uploader('Upload any file format with text to analyze:', accept_multiple_files=True)

        # chunk size number widget
        global chunk_size
        chunk_size = st.number_input('Chunk size:', min_value=100, max_value=8192, value=512)

        # k number input widget
        global k
        k = st.number_input(' Instances:', min_value=1, max_value=20, value=3)

        # add data button widget
        add_data = None

        st.button('Clear Session & Vectors', on_click=click_button)
        
        if is_api_key_valid(api_key):
            add_data = st.button('Add Data')
        else:
            st.info('No OpenAI API key. Please provide a valid key.')
        
        
        #if uploaded_files and add_data: # if the user uploaded files and clicked the add data button
            #check_openai_api_key_exist()
            #st.session_state.vs = None
            #if st.session_state:
            

                 
        #background: #ff0099; 
        #background: -webkit-linear-gradient(to right, #ff0099, #493240); 
        #background: linear-gradient(to right, #ff0099, #493240);"

        #st.markdown("""
        #<style>
        #body {
        #background: #ff0099; 
        #background: -webkit-linear-gradient(to right, #ff0099, #493240); 
        #background: linear-gradient(to right, #ff0099, #493240); 
        #}
        #</style>
        #    """, unsafe_allow_html=True)    
        
        
    #if uploaded_files and 'vs' in st.session_state and is_api_key_valid(api_key):
    if uploaded_files  and is_api_key_valid(api_key):
        q = text1
        i=1
        dfmajor = pd.DataFrame()
        dff = pd.DataFrame()
        #columns=['Features', 'Analysis'])
        #st.header("QUALITATIVE INSIGHTS")
        

        for uploaded_file in uploaded_files:
            if not os.path.exists('./docs/'):
                    os.mkdir('./docs/')

            # list to store all the chunks
            all_chunks = []
            # writing the file from RAM to the current directory on disk
            bytes_data = uploaded_file.read()
            file_name = os.path.join('./docs/', uploaded_file.name)
            with open(file_name, 'wb') as f:
                f.write(bytes_data)

            data = load_document(file_name)
            chunks = chunk_data(data, chunk_size=chunk_size)
            #st.write(f'File name: {os.path.basename(file_name)}, Chunk size: {chunk_size}, Chunks: {len(chunks)}')
            all_chunks.extend(chunks)

            tokens, embedding_cost = calculate_embedding_cost(all_chunks)
            #st.write(f'Embedding cost: ${embedding_cost:.4f}')

            # creating the embeddings and returning the Chroma vector store
            vector_store = create_embeddings(all_chunks)

            # saving the vector store in the streamlit session state (to be persistent between reruns)
            st.session_state.vs = vector_store
            #st.success('Uploaded, chunked and embedded successfully.')
            answer = ask_and_get_answer(vector_store, q, k)
            
            # deleting files from the docs folder after they have been chunked and embedded
            #for file in os.listdir('./docs/'):
            #   os.remove(os.path.join('./docs/', file))

            #    # deleting the docs folder
            #    os.rmdir('./docs/')
            for filename in os.listdir('./docs'):
                file_path = os.path.join('./docs', filename)
                try:
                    if os.path.isfile(file_path) or os.path.islink(file_path):
                        os.unlink(file_path)
                    elif os.path.isdir(file_path):
                        shutil.rmtree(file_path)
                except Exception as e:
                    print('Failed to delete %s. Reason: %s' % (file_path, e))

            os.rmdir('./docs')
           #st.text_area("INSIGHT "+ str(i) + " :", value=answer, height=300, key=i)
            
            
            # Create and Display the dataframe with json file
            
            #
            #st.caption("QUALITATIVE INSIGHTS")
            i+=1
            #st.write(anstodf(answer))
            data = answer
            if data.startswith('{') or data.startswith('['):
                #st.write("Probably JSON")
                #st.write(uploaded_file.name)
                now = datetime.now()
                current_time = now.strftime("%H:%M:%S")
                current_date = now.strftime("%d-%m-%Y")
                timezone = datetime.now(tz=None).astimezone().tzinfo
                #st.write(current_date + " " + current_time + " " + str(timezone))
                tdtz = current_date + " " + current_time + " " + str(timezone)
                # Load JSON data
                #st.write(data)
                data = json.loads(data)

                # Convert to DataFrame
                #index=[0,1]
                df = pd.DataFrame(data, index=[0])
                #df = pd.DataFrame(data)
                #st.write(df)
               
                #dfmajor = dfmajor.append({'Features': df[0], 'Analysis': df[1]}, ignore_index=True)
                df.loc[:,'FileName'] = uploaded_file.name
                df.loc[:,'UID'] = uploaded_file.name + " " + tdtz
                
                dfmajor = pd.concat([dfmajor, df], ignore_index=True)
                
                #random_nums = np.random.randint(10000, 99999)
                #random_nums +=1
                #dfmajor['Customer Id'] = str(random_nums)
                
                #NW dff = dff.append({df}, ignore_index = True)
                # Convert the dataframe to csv
                #st.write(dfmajor)
                #df.to_csv('output.csv', index=False)
                #csvf = df.to_csv( index=False)
                #st.write(csvf)
                i = i + 1
                # Display the csv file
                #btn1 = st.download_button(label="Download CSV", data=csvf, file_name='output1.csv', mime='text/csv',key='btn1')
            else:
                    st.write("Probably not JSON")
                    # Extract lines
                    #aa = """ aa """
                    st.caption("data")
                    st.write(data)
                    data = answer
                    lines = data.splitlines()

                    # Create empty lists
                    
                    feature = []
                    value = []

                    # Loop through lines to extract features and values
                    for line in lines:
                        # Split line on colon
                        parts = line.split(":")
                
                        #st.write(parts)
                    # First part is feature
                        feature.append(parts[0].strip()) 
                
                    # Second part is value
                        value.append(parts[1].strip())
    
                    # Create dataframe  
                    df1 = pd.DataFrame({
                        "Feature": feature,
                        "Value": value
                    })
                    pattern = r'^\d*\.'  

                    # Lambda function to strip digits
                    strip_digits = lambda x: re.sub(pattern, '', x)

                    # Apply to column 
                    df1['Feature'] = df1['Feature'].apply(strip_digits)
                    # Print dataframe
                    df2 = df1.transpose()
                    st.caption("df1")
                    st.write(df1)
                    st.caption("df2")
                    st.write(df2)
                    st.header("QUALITATIVE INSIGHTS")
                    dfmajor = pd.concat([dfmajor, df2], ignore_index=True)
                    #NW dff = dff.append({df}, ignore_index = True)
        
        
        # Add new column 
        #rand_indexes = np.random.randint(1, 100, len(dfmajor))

        # Set the dataframe index to be the random indexes
        #dfmajor.index = rand_indexes
        st.header("QUALITATIVE INSIGHTS")
        st.write(dfmajor)
        #dfmajornew = dfmajor.reset_index(drop=True)
        #st.write(dfmajornew)    
        
        #st.write(csvf)
        # Button to download the csv file
        csvf = dfmajor.to_csv(index=False)
        dfmajor.to_csv('output_store.csv', mode='a', index=False, header=False)
        st.markdown(f"""
        <style>
        div[data-testid="stMarkdownContainer"] button {{
            background-color: purple;
            color: white;
        }}
        </style>
        """, unsafe_allow_html=True)


        btn2 = st.download_button(label="Download Output", data=csvf, file_name='dfmajorcsvfile.csv', mime='text/csv',key='btn2')
        
        

        count = 10

        # Create a container for the tile and set styling
        #container = st.container()
        #container.write(f"<h1 style='text-align:left; color:Dodgerblue;'>{count} Transcripts analyzed so far</h1>", unsafe_allow_html=True)

        # Increment count variable
        count += 5
        start_over_with_new_document() 
        

        #local_css("style.css")
        
        

        
        # Define the color and style of the box
        style = """
        
        <style>
        .colored-box {
            width: 300px; 
            height: 300px;
            
            background-color: #00000;  
            border-left: 5px solid #337ACE;
            border-right: 5px solid #337ACE;
            border-top: 5px solid #337ACE;
            border-bottom: 5px solid #337ACE;
            padding: 50px;  
            padding-top: 5rem;
            padding-right: 5rem; 
            padding-left: 5rem;
            padding-bottom: 5rem;
            border-radius: 10px; 
            text-align: center;
        }
        </style>
        """
        st.header("QUANTITATIVE INSIGHTS")
        col1, col2, col3, col4 = st.columns(4)
        # tile 01 calculation
        row_count = 0
        with open('output_store.csv') as f:
            reader = csv.reader(f)
            for row in reader:
                row_count += 1
        num_tran = row_count

        #tile 2 calculation
        value_to_count = ""
        column_name = "Service sold"
        column_name_int_stat = "Internet Speed Question"
        #column_name = "Emerald Sold by Agent"
        totalsales = 0
        internetsales = 0
        missedsalesforinternetProducts = 0
        with open('output_store.csv') as f:
            reader = csv.reader(f)
            headers = next(reader)
            #st.write(headers)
            
            column_index = headers.index(column_name) 
            column_index_internet_stat = headers.index(column_name_int_stat) 

            for row in reader:
                #if row[column_index] != None:
                #st.write(row[column_index])
                if row[column_index].__contains__("TVCOMPE") or row[column_index].__contains__("TVCOMPI"):
                    internetsales +=1
                if row[column_index].__contains__("TVCOMP"):
                    totalsales += 1
                if row[column_index].__contains__("TVCOMPS") and row[column_index_internet_stat].__contains__("Speed asked"):
                    missedsalesforinternetProducts += 1
    
            
        perc_suc = round((totalsales/num_tran)*100, 2)
        int_sales = round((internetsales/totalsales)*100, 2)
        missed_opty = round((missedsalesforinternetProducts/totalsales)*100, 2)
        st.write("number of lines in output store: " + str(num_tran))
        st.write("total sales TVCOMP :" + str(totalsales))
        st.write("total internet sales :" + str(internetsales))
        st.write("missedsales for internet products(TVCOMPS when internet stat not asked) :" + str(missedsalesforinternetProducts))
        
        with col1:
            st.header("")
            #st.markdown(f'<div class="colored-box"><div style="color: blue; font:Font PF Din text Pro Medium ;font-size: 34px; text-align: center; font-weight: bold;">{num_tran}</div> <div style="color: blue; text-align: center; font-size: 18px; font-weight: bold;"><br>Transcripts Analyzed</div></div>', unsafe_allow_html=True)
            st.markdown(f'<div class="colored-box"><div style="color: blue; font-size: 34px; text-align: center; font-weight: bold;">{num_tran} </div> <div style="color: blue; text-align: center; font-size: 18px; font-weight: bold;"><br>Transcripts Analyzed</div></div>', unsafe_allow_html=True)
        
        with col2:
            st.header("")
            st.markdown(f'<div class="colored-box"><div style="color: blue; font-size: 34px; text-align: center; font-weight: bold;">{perc_suc} %</div> <div style="color: blue; text-align: center; font-size: 18px; font-weight: bold;"><br>Overall Sales</div></div>', unsafe_allow_html=True)

        with col3:
            st.header("")
            st.markdown(f'<div class="colored-box"><div style="color: blue; font-size: 34px; text-align: center; font-weight: bold;">{missed_opty} %</div> <div style="color: blue; text-align: center; font-size: 18px; font-weight: bold;"><br>Missed Opportunities</div></div>', unsafe_allow_html=True)
            
        # Include the style in the markdown
        #st.markdown(style, unsafe_allow_html=True)

        with col4:
            st.header("")
            st.markdown(f'<div class="colored-box"><div style="color: blue; font-size: 34px; text-align: center; font-weight: bold;">{int_sales} %</div> <div style="color: blue; text-align: center; font-size: 18px; font-weight: bold;"><br>KPI Internet Sale(TVCOMPE or TVCOMPI)</div></div>', unsafe_allow_html=True)
        # Include the style in the markdown
        st.markdown(style, unsafe_allow_html=True)
        #t = "<div>Hello there my <span class='highlight blue'>name <span class='bold'>yo</span> </span> is <span class='highlight red'>Fanilo <span class='bold'>Name</span></span></div>"
        #st.markdown(t, unsafe_allow_html=True)
        # Use the custom style in a markdown string
        #st.markdown('<div class="colored-box">This text is inside a colored box!</div>', unsafe_allow_html=True)
        #st.markdown(f'<p style="background-color:#0066cc;color:#33ff33;font-size:24px;border-radius:2%;">hey Deejey</p>', unsafe_allow_html=True)
        
        ## new df hist and pie code chart from here
        dfhist = pd.DataFrame(index=['TVCOMPI', 'TVCOMPE', 'TVCOMPS', 'No Sale'], 
                  columns=['not asked', 'asked', 'Total']) 
        counttvcompe_a = 0
        counttvcompe_na = 0
        counttvcompi_a = 0
        counttvcompi_na = 0
        counttvcomps_a = 0
        counttvcomps_na = 0
        counttvcompnosale_a = 0
        counttvcompnosale_na = 0
        
        

        opstore_colname_a = "Internet Speed Question"
        opstore_colname_b = "Service sold"

        with open('output_store.csv') as f:
            reader = csv.reader(f)
            headers = next(reader)
            column_index_a = headers.index(opstore_colname_a) 
            column_index_b = headers.index(opstore_colname_b) 

            for row in reader:
                #if row[column_index] != None:
                #st.write(row[column_index])
                if row[column_index_b].__contains__("TVCOMPE") and row[column_index_a].__contains__("Speed asked"):
                    counttvcompe_a += 1
                
                elif row[column_index_b].__contains__("TVCOMPE") and row[column_index_a].__contains__("Speed not asked"):
                    counttvcompe_na += 1

                elif row[column_index_b].__contains__("TVCOMPI") and row[column_index_a].__contains__("Speed asked"):
                    counttvcompi_a += 1
                
                elif row[column_index_b].__contains__("TVCOMPI") and row[column_index_a].__contains__("Speed not asked"):
                    counttvcompi_na += 1
                
                elif row[column_index_b].__contains__("TVCOMPS") and row[column_index_a].__contains__("Speed asked"):
                    counttvcomps_a += 1
                
                elif row[column_index_b].__contains__("TVCOMPS") and row[column_index_a].__contains__("Speed not asked"):
                    counttvcomps_na += 1
                
                elif row[column_index_b].__contains__("No sale") and row[column_index_a].__contains__("Speed asked"):
                    counttvcompnosale_a += 1
                
                elif row[column_index_b].__contains__("No sale") and row[column_index_a].__contains__("Speed not asked"):
                    counttvcompnosale_na += 1

            dfhist.loc['TVCOMPE', 'asked'] = counttvcompe_na
            dfhist.loc['TVCOMPE', 'not asked'] = counttvcompe_a
            dfhist.loc['TVCOMPE', 'Total'] = counttvcompe_a + counttvcompe_na
            dfhist.loc['TVCOMPI', 'asked'] = counttvcompi_na
            dfhist.loc['TVCOMPI', 'not asked'] = counttvcompi_a
            dfhist.loc['TVCOMPI', 'Total'] = counttvcompi_a + counttvcompi_na
            dfhist.loc['TVCOMPS', 'asked'] = counttvcomps_na
            dfhist.loc['TVCOMPS', 'not asked'] = counttvcomps_a
            dfhist.loc['TVCOMPS', 'Total'] = counttvcomps_a + counttvcomps_na
            counttvcompnosale_a = 25
            dfhist.loc['No Sale', 'asked'] = counttvcompnosale_a
            dfhist.loc['No Sale', 'not asked'] = counttvcompnosale_na
            dfhist.loc['No Sale', 'Total'] = counttvcompnosale_na + counttvcompnosale_a
            st.write(dfhist)
        ## new dfhist & pie code chart till here
            
        colpie, colbar = st.columns(2)
        df = pd.DataFrame({'Category': ['TVCOMPE',
                                        'TVCOMPI',
                                        'TVCOMPS',
                                        'No Sales'
                                        ], 'Values': [dfhist.loc['TVCOMPE', 'Total'],
                                                        dfhist.loc['TVCOMPI', 'Total'],
                                                        dfhist.loc['TVCOMPS', 'Total'],
                                                        dfhist.loc['No Sale', 'Total']
                                                        ]}) 

        # Set page title and chart header
        #st.title("Pie Chart Example")
        with colpie:
            st.header("Sales Data Distribution")
        

            # Create pie chart figure using plotly express
            fig = px.pie(df, values='Values', names='Category', 
                        title='', hole=0.5)

            # Set legend position and colors                  
            fig.update_traces(marker=dict(colors=['#636EFA','#EF553B','#00CC96']))
            #fig.update_traces(marker=dict(line=dict(colors=['#636EFA','#EF553B','#00CC96'],width=2)))
            #fig.update_layout(legend=dict(orientation='top', xanchor="left", valign="start", x=0.1 ))
            # Update the legend position
            fig.update_layout(
                legend=dict(
                    orientation="v",
                    yanchor="middle",
                    y=0.5,
                    xanchor="left",
                    x=0.01
                )
            )
            # Display chart
            st.plotly_chart(fig)

        

        #st.header("Products Sales Chart")
        x_col = ['TVCOMPI', 'TVCOMPE', 'TVCOMPS', 'No Sale']
        y_col = ['not asked', 'asked']
        # Create histogram
        with colbar:
            fig = px.histogram(dfhist, x= x_col, y= y_col,
                            nbins=8, 
                            title='',
                            barmode = 'group',
                            #text = df['Values'], 
                            #textposition='outside'
                            )

            # Customize axis labels
            fig.update_layout(xaxis_title="Products",  
                            yaxis_title="Sales")

            # Display chart
            st.plotly_chart(fig)
        
        

        ## sankey sample code from here
        #labels = ["Total Customers", "Asked Internet Status", 
        #          "Not Asked", "TVCOMPE", "TVCOMPS", "TVCOMPI", "No Sale"]

        #source = [0, 1, 1, 3, 3, 3, 1, 2, 4, 4, 5]
        #target = [1, 2, 3, 4, 5, 6, 6, 6, 6, 6, 6]
        #values = [100, 56, 44, 15, 10, 25, 6, 20, 4, 12, 8] 

        #node_colors = ['lightblue', 'crimson', 'darkorange', 'royalblue',
        #               'seagreen','pink', 'gold']

        #fig = go.Figure(data=[go.Sankey(
        #    node = dict(
        #    pad = 20,
        #    thickness = 30,
        #    line = dict(color = "black", width = 0.5),    
        #    label =  labels,
        #    color =  node_colors
        #    ),
        #    link = dict(
        #    source = source,  
        #    target = target,
        #    value =  values
        #))])

        #fig.update_layout(title_text="Telecom Sales Sankey Diagram", font_size=15)

        #st.plotly_chart(fig)
        
        ## Sankey diag code till here
        import plotly.graph_objects as go

            # Define the labels and source-target links for the Sankey diagram
        #labels = ['Total Customers', 'Internet Status Asked', 'Internet Status Not Asked', 
        #          'No Sale', 'TVCOMPE', 'TVCOMPS', 'TVCOMPI']
        labels1 = ['Total Customers',	'Internet Status Asked',	'Internet Status not Asked',	'TVCOMPE', 'TVCOMPI',	'TVCOMPS',	'No Sale']

        #source = [0, 0, 0, 1, 1, 2, 2]
        source1 = [0,0,1,1,1,1,2,2,2,2]
        #target = [1, 2, 3, 4, 5, 3, 4]
        target1 = [1,2,3,4,5,6,3,4,5,6]
        # Define the link values based on the provided data
        #value = [115, 44, 79, 8, 45,52, 12]
        value1 = [(dfhist.loc['TVCOMPE', 'asked'] + dfhist.loc['TVCOMPI', 'asked'] + dfhist.loc['TVCOMPS', 'asked'] + dfhist.loc['No Sale', 'asked']),
                  (dfhist.loc['TVCOMPE', 'not asked'] + dfhist.loc['TVCOMPI', 'not asked'] + dfhist.loc['TVCOMPS', 'not asked'] + dfhist.loc['No Sale', 'not asked']),
                  dfhist.loc['TVCOMPE', 'asked'],
                  dfhist.loc['TVCOMPI', 'asked'],
                  dfhist.loc['TVCOMPS', 'asked'],
                  dfhist.loc['No Sale', 'asked'],
                  dfhist.loc['TVCOMPE', 'not asked'],
                  dfhist.loc['TVCOMPI', 'not asked'],
                  dfhist.loc['TVCOMPS', 'not asked'],
                  dfhist.loc['No Sale', 'not asked']]

        # Define color for each node group
        colors = ['#3366cc','#579985', '#714c9f',  '#109618', '#990099', '#0099c6', '#dd4477']


        # Create the Sankey diagram trace
        trace = go.Sankey(
            node=dict(
                pad=15,
                thickness=20,
                line=dict(color='black', width=0.5),
                label=labels1,
                color=colors
            ),
            link=dict(
                source=source1,
                target=target1,
                value=value1
            )
        )

        # Create the layout for the Sankey diagram
        layout = go.Layout(
            title_text="TVCOMP Sales Sankey Diagram",
            font=dict(size=16),
            height=600,
            width=1100,
        )

        # Create the figure and plot the Sankey diagram
        fig = go.Figure(data=[trace], layout=layout)
        #fig.show()
        st.plotly_chart(fig)
        
        c1, c2 = st.columns([3,1])

        with c1:
            #st.image('DOX_BIG.png', caption=None, width=150, use_column_width=150, clamp=True, channels="RGB", output_format="auto")
            #st.divider()
            st.markdown(f'')
        with c2:
            #st.image('Amdocs.jpg')
        #    
        #<img src="Amdocs.jpg" style="position: fixed; bottom: 0; right: 0;" width="100">""", unsafe_allow_html=True)
        #st.markdown(f'Developed By Amdocs')
            #st.image('DOX_BIG.png', caption=None, width=150, use_column_width=150, clamp=True, channels="RGB", output_format="auto")
            #st.markdown(f'<div class="colored-box"><div style="color: black; font:Font PF Din text Pro Medium ;font-size: 14px; text-align: center; font-weight: bold;"></div> <div style="color: blue; text-align: center; font-size: 14px; font-weight: bold;"></div>', unsafe_allow_html=True)
            st.markdown(f'')
            #st.divider()
        st.image('DOX_BIG.png', caption=None, width=150, use_column_width=150, clamp=True, channels="RGB", output_format="auto")
        st.divider()    
    else:
        c1, c2 = st.columns([3,1])

        with c1:
            st.markdown(f'')
            #st.image('DOX_BIG.png', caption=None, width=100, use_column_width=100, clamp=True, channels="RGB", output_format="auto")
        with c2:
            #st.image('Amdocs.jpg')
        #    
        #<img src="Amdocs.jpg" style="position: fixed; bottom: 0; right: 0;" width="100">""", unsafe_allow_html=True)
        #st.markdown(f'Developed By Amdocs')
            #
            st.markdown(f'')
            #st.markdown(f'<div class="colored-box"><div style="color: black; font:Font PF Din text Pro Medium ;font-size: 14px; text-align: center; font-weight: bold;"></div> <div style="color: blue; text-align: center; font-size: 14px; font-weight: bold;"></div>', unsafe_allow_html=True)
        st.image('DOX_BIG.png', caption=None, width=100, use_column_width=100, clamp=True, channels="RGB", output_format="auto")
        st.divider() #st.info('Please upload one or more files to continue.')

